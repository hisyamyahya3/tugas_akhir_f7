export default {
  name: 'link'
};